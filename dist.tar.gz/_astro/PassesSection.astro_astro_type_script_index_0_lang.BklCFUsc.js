let r=[];async function f(){if(document.getElementById("passesGrid"))try{const s=await(await fetch("/api/passes/types")).json();s.success&&s.data&&s.data.length>0?(r=s.data,m(s.data,s.paymentInfo)):d()}catch(t){console.warn("[Passes] API offline, rendering fallback passes:",t),d()}}function m(a,t){const s=document.getElementById("passesGrid");s&&(s.innerHTML=a.map(e=>`
      <div class="pass-card ${e.promo_badge?"is-popular":""}">
        ${e.promo_badge?`<span class="badge badge-sunset pass-badge">${e.promo_badge}</span>`:""}
        
        <div class="pass-header">
          <h3 class="pass-name">${e.name}</h3>
          <p class="pass-desc">${e.description}</p>
        </div>

        <div class="pass-pricing-block">
          <div class="pass-price">
            <span>${e.price_promo?e.price_promo.toFixed(2):e.price_regular.toFixed(2)}</span>
            <span class="currency">PLN</span>
          </div>
          <div class="pass-entries-info">
            <i class="fa-solid fa-ticket"></i>
            <span>${e.entries_count===999?"Wstęp Nielimitowany (VIP)":`${e.entries_count} sesji w pakiecie`}</span>
          </div>
        </div>

        <ul class="pass-features-list">
          <li><i class="fa-solid fa-check"></i> <span>Ważność: <strong>${e.validity_days} dni</strong> w sezonie ${e.season}</span></li>
          <li><i class="fa-solid fa-check"></i> <span>${e.includes_equipment?"Wypożyczenie deski w cenie":"Dostęp do toru (sprzęt własny / dopłata 20 zł)"}</span></li>
          <li><i class="fa-solid fa-check"></i> <span>Kask i kamizelka asekuracyjna w cenie</span></li>
          <li><i class="fa-solid fa-check"></i> <span>Szybka rezerwacja slotów online</span></li>
        </ul>

        <button type="button" class="btn btn-primary buy-pass-btn" data-pass-id="${e.id}">
          <i class="fa-solid fa-bag-shopping"></i> Zamów Karnet
        </button>
      </div>
    `).join(""),g())}function d(){const a=[{id:"pass_5_regular",name:"Karnet 5 Sesji (Własny Sprzęt)",price_regular:220,entries_count:5,validity_days:120,season:"2027",description:"Pakiet 5 pojedynczych godzinnych sesji na wyciągu Sesitec 2.0."},{id:"pass_10_regular",name:"Karnet 10 Sesji (Bestseller)",price_regular:420,entries_count:10,validity_days:150,season:"2027",promo_badge:"Najchętniej Wybierany",description:"Optymalny pakiet dla regularnie trenujących ridersów."},{id:"pass_5_full",name:"Karnet 5 Sesji (Z Deską)",price_regular:310,entries_count:5,validity_days:120,season:"2027",includes_equipment:1,description:"5 sesji z kompletną deską wakeboardową w cenie."},{id:"pass_vip_season",name:"Karnet Sezonowy VIP 2027",price_regular:2490,entries_count:999,validity_days:180,season:"2027",promo_badge:"Edycja Limitowana",description:"Nielimitowane pływanie przez cały sezon 2027."}];r=a,m(a)}function g(){document.querySelectorAll(".buy-pass-btn").forEach(a=>{a.addEventListener("click",t=>{const s=t.currentTarget.getAttribute("data-pass-id");I(s)})})}const i=document.getElementById("passOrderModal"),b=document.getElementById("modalCloseBtn"),E=document.getElementById("modalCancelBtn"),k=document.getElementById("passPurchaseForm"),p=document.getElementById("orderStepForm"),u=document.getElementById("orderStepSuccess");function I(a){const t=r.find(e=>e.id===a);if(!t||!i)return;document.getElementById("formPassTypeId").value=t.id,document.getElementById("modalPassName").textContent=t.name;const s=t.price_promo||t.price_regular;document.getElementById("modalPassPrice").textContent=`${s.toFixed(2)} PLN`,p.style.display="block",u.style.display="none",i.classList.add("is-open"),i.setAttribute("aria-hidden","false"),document.body.style.overflow="hidden"}function o(){i&&(i.classList.remove("is-open"),i.setAttribute("aria-hidden","true"),document.body.style.overflow="")}b?.addEventListener("click",o);E?.addEventListener("click",o);document.getElementById("closeSuccessBtn")?.addEventListener("click",o);i?.addEventListener("click",a=>{a.target===i&&o()});k?.addEventListener("submit",async a=>{a.preventDefault();const t=document.getElementById("modalSubmitBtn");t.disabled=!0,t.innerHTML='<i class="fa-solid fa-spinner fa-spin"></i> Zapisywanie zamówienia...';const s={passTypeId:document.getElementById("formPassTypeId").value,customerName:document.getElementById("custName").value,customerEmail:document.getElementById("custEmail").value,customerPhone:document.getElementById("custPhone").value};try{const n=await(await fetch("/api/passes/order",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(s)})).json();n.success&&n.order?l(n.order):alert(n.error||"Wystąpił błąd podczas składania zamówienia.")}catch(e){console.error("[Order Error]",e);const n=`WARP-2027-${Math.floor(1e3+Math.random()*9e3)}`;l({orderNumber:n,paymentDetails:{recipientName:"WAKE & ROLL PARK S.C.",accountNumber:"OCZEKUJE NA UZUPEŁNIENIE W PANELU ADMINA",amountDue:document.getElementById("modalPassPrice").textContent,transferTitle:`KARNET ${n} ${s.customerName.split(" ").slice(-1)[0].toUpperCase()}`,isTestMode:!0,bankConfigured:!1}})}finally{t.disabled=!1,t.innerHTML='<span>Złóż zamówienie i przejdź do płatności</span> <i class="fa-solid fa-arrow-right"></i>'}});function l(a){p.style.display="none",u.style.display="block";const t=a.paymentDetails;document.getElementById("successOrderNumber").textContent=a.orderNumber,document.getElementById("bankRecipient").textContent=t.recipientName,document.getElementById("bankAccount").textContent=t.accountNumber,document.getElementById("bankAmount").textContent=t.amountDue,document.getElementById("bankTitle").textContent=t.transferTitle;const s=document.getElementById("transferModeAlert");!t.bankConfigured&&s?s.style.display="flex":s&&(s.style.display="none"),document.querySelectorAll(".copy-btn").forEach(e=>{e.addEventListener("click",n=>{const y=n.currentTarget.getAttribute("data-copy"),c=document.getElementById(y)?.textContent;c&&(navigator.clipboard.writeText(c),e.innerHTML='<i class="fa-solid fa-check"></i>',setTimeout(()=>{e.innerHTML='<i class="fa-regular fa-copy"></i>'},1500))})})}document.addEventListener("DOMContentLoaded",f);
